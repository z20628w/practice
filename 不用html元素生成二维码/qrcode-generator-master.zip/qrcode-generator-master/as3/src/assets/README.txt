QRCode for ActionScript3

Copyright (c) 2009 Kazuhiko Arase

URL: http://www.d-project.com/

Licensed under the MIT license:
  http://www.opensource.org/licenses/mit-license.php

The word "QR Code" is registered trademark of 
DENSO WAVE INCORPORATED
  http://www.denso-wave.com/qrcode/faqpatent-e.html


-- REQUIREMENTS

FlashPlayer 9.0.28 or above

-- CONTENTS

README.txt        - this file
qrcode.swc        - library
sample            - sample
apidocs           - API document
