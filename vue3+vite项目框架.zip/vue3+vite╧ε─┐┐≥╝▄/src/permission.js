import router from './router';
import store from './store';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import { getToken, getUserinfo } from '@/utils/auth';

NProgress.configure({ showSpinner: false });

// 不需要token就能进的页面的name
const whiteList = ['login'];

router.beforeEach((to, from, next) => {

	let token = getToken();
	let userinfo = getUserinfo();

	NProgress.start();

	// 页面切换关闭全局动画加载
	store.dispatch('settings/changeSetting', {
		key: 'loading',
		value: false
	});

	// 必须同时拥有token与用户信息才可进入
	if (token && userinfo) {
		// 更新token与用户信息
		store.dispatch('user/changeUser', {
			key: 'token',
			value: token
		});
		store.dispatch('user/changeUser', {
			key: 'userinfo',
			value: userinfo
		});

		/* 进入页面 */
		if (to.path === '/login') {
			next({ path: '/' });
		} else {
			next()
		}
	} else {
		// 更新token与用户信息
		store.dispatch('user/changeUser', {
			key: 'token',
			value: null
		});
		store.dispatch('user/changeUser', {
			key: 'userinfo',
			value: null
		});

		// 没有token
		if (whiteList.includes(to.name) || whiteList.includes("*.*")) {
			// 在免登录白名单，直接进入
			next();
		} else {
			next(`/login`); // 否则全部重定向到登录页
		}
	}
});

router.afterEach((to, form) => {
	// 进入页面后控制当前页面是否缓存
	if (to.name == 'login') {
		// 进入登录页面，取消全部页面的缓存
		store.commit("user/SET_PAGECACHES", { value: '', type: 2 })
	} else {
		// 判断是否需要缓存
		if (to.meta.cache) {
			store.commit("user/SET_PAGECACHES", { value: to.name, type: 1 })
		} else {
			store.commit("user/SET_PAGECACHES", { value: to.name, type: 0 })
		}
	}
	NProgress.done();
});
