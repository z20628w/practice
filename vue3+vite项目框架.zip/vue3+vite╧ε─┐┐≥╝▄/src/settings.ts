const settings: object = {
   /**
   * 是否开启加载动画
   */
   loading: false,

   // 当前屏幕宽度对比750设计稿宽度缩放比例
   bl: window.innerWidth / 750
};

export default settings
