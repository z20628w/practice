<template>
  <div class="login bsbb">
    <!-- 顶部logo -->
    <div class="logo">
      <div class="img fcc">
        <van-image width="1.42rem" height="1.38rem" round fit="cover" :src="logo" />
      </div>
      <div class="text fcc bold">沙拉食刻数据统计</div>
    </div>

    <!-- 输入框 -->
    <div class="text-input">
      <!-- 密码版登录 -->
      <van-form v-if="loginType == 1" @submit="submit_pass" ref="van-form">
        <!-- 账号输入 -->
        <div class="username">
          <van-field v-model="formData.phone" type="text" placeholder="请输入账户" :rules="[{ required:true, message: '请输入账户名称' }]" @keydown.enter="loginFn" />
        </div>

        <!-- 密码码输入 -->
        <div class="password">
          <van-field v-model="formData.password" type="password" placeholder="请输入密码" :rules="[{ required:true, message: '请输入密码' }]" @keydown.enter="loginFn"></van-field>
        </div>
      </van-form>

      <!-- 验证码登录 -->
      <van-form v-else-if="loginType == 2" @submit="submit_code" ref="van-form">
        <!-- 账号输入 -->
        <div class="username">
          <van-field v-model="formData.phone" type="digit" placeholder="请输入手机号" :rules="[{ pattern:mobilePattern, message: '请输入正确手机号' }]" @keydown.enter="loginFn" />
        </div>

        <!-- 验证码输入 -->
        <div class="code">
          <van-field v-model="formData.captcha" type="text" placeholder="请输入验证码" :rules="[{ required:true, message: '请输入验证码' }]" @keydown.enter="loginFn">
            <template #button>
              <div v-if="countDown <= 0 " class="VCode fs28 fcc" :class="[formData.phone ? '' : 'disabled']" @click="sendVCodeFn">发送验证码</div>
              <div v-else class="VCode fs28 fcc">{{countDown}}秒后重发</div>
            </template>
          </van-field>
        </div>
      </van-form>
    </div>

    <div class="buts">
      <van-button block round type="primary" :disabled="!isDisabled" class="fs28" native-type="submit" @click="loginFn">登录</van-button>
      <van-button block round type="primary" plain class="fs28 mt24" @click="loginTypeFn">{{loginType == 1 ? '验证码':'密码'}}登录</van-button>
    </div>

  </div>
</template>
<script>
import { mapActions } from "vuex";
import { getToken, setToken, removeToken, getUserinfo, setUserinfo, removeUserinfo, getLocalStorageCache, setLocalStorageCache, removeLocalStorageCache } from "@/utils/auth.js"
import { mobilePattern } from "@/utils/validate.js"
import logo from "@/assets/image/login/img_logo.png";
import { Toast } from 'vant';
import { login_pass, login_code, get_loginCode } from "@/api/login.js"
export default {
  name: "login",

  components: {},

  data () {
    return {
      logo,

      formData: {
        phone: "",
        password: "",
        captcha: ""
      },

      // 登录方式 1 -- 密码 2 -- 验证码
      loginType: 2,

      // 手机验证
      mobilePattern,

      // 验证码倒计时
      countDown: 0,

      // 需要返回的页面路径
      redirect: undefined,
    };
  },

  computed: {
    isDisabled: function () {
      if (this.loginType == 1) return !!this.formData.phone && !!this.formData.password
      else if (this.loginType == 2) return !!this.formData.phone && !!this.formData.captcha
    }
  },

  mounted () { },

  methods: {
    ...mapActions({
      changeUser: "user/changeUser"
    }),

    // 获取验证码
    async sendVCodeFn () {
      if (!this.formData.phone) return;
      let res = {
        result: "错误",
        message: "错误",
      };

      try {
        res = await get_loginCode({ phone: this.formData.phone })
      } catch (error) {
      }

      if (res.result != 200) {
        Toast.fail(res.message || '验证码获取失败，请重试');
        return;
      }

      this.setCodeCountDown()
    },

    // 获取验证码倒计时
    getCodeCountDown () {
      // 获取存储的时间戳
      let time = getLocalStorageCache('VCODE') || new Date().getTime();

      // 计算当前时间距离获取的时间间隔（秒）
      let m = (time - new Date().getTime()) / 1000;

      this.countDown = Math.ceil(m);

      if (this.countDown > 0) {
        setTimeout(() => {
          this.getCodeCountDown()
        }, 1000)
      } else {
        // 时间到就删除
        removeLocalStorageCache("VCODE")
      }
    },

    // 设置验证码倒计时结束日期
    setCodeCountDown (m = 60) {
      /**
       * m : 间隔时间（秒）
      */

      // 间隔后的时间的时间戳
      let time = new Date().getTime() + m * 1000;

      setLocalStorageCache('VCODE', time, 1)

      this.getCodeCountDown()
    },

    loginFn () {
      // 触发验证
      this.$refs['van-form'].submit()
    },

    // 表单验证通过事件(密码版)
    async submit_pass () {
      let res = {
        result: "错误",
        message: "错误",
      };

      let query = {
        phone: this.formData.phone,
        password: this.formData.password
      }

      try {
        res = await login_pass(query)
      } catch (error) {
      }

      if (res.result != 200) {
        Toast.fail(res.message || '登录失败，请重试');
        return;
      }
      let data = res.data;

      data.token = `Bearer ${data.token}`;

      setToken(data.token);

      let userinfo = { ...data };
      setUserinfo(JSON.stringify(userinfo));

      // 清除验证码
      removeLocalStorageCache("VCODE")

      Toast.success('登录成功');

      this.$router.replace({
        path: this.redirect || "/",
      });

    },

    // 表单验证通过事件(验证码版)
    async submit_code () {
      let res = {
        result: "错误",
        message: "错误",
      };

      let query = {
        phone: this.formData.phone,
        captcha: this.formData.captcha
      }

      try {
        res = await login_code(query)
      } catch (error) {
      }

      if (res.result != 200) {
        Toast.fail(res.message || '登录失败，请重试');
        return;
      }
      let data = res.data;

      data.token = `Bearer ${data.token}`;

      setToken(data.token);

      let userinfo = { ...data };
      setUserinfo(JSON.stringify(userinfo));

      // 清除验证码
      removeLocalStorageCache("VCODE")

      Toast.success('登录成功');

      this.$router.replace({
        path: this.redirect || "/",
      });

    },

    // 登录切换
    loginTypeFn () {
      this.formData.phone = '';
      this.formData.password = '';
      this.formData.captcha = '';
      switch (this.loginType) {
        case 1:
          this.loginType = 2;
          break;
        case 2:
          this.loginType = 1;
          break;
      }
    }
  },

  watch: {
    $route: {
      handler: function (newVal) {
        this.redirect = newVal.query && newVal.query.redirect;
      },
      immediate: true,
    },
  },
};
</script>
<style lang="scss" scoped>
.login {
  padding: 0.24rem;
  padding-top: 1.42rem;
  .logo {
    width: 100%;
    margin-bottom: 1.4rem;
    .img {
      width: 100%;
      margin-bottom: 0.25rem;
    }

    .text {
      width: 100%;
      font-size: 0.4rem;
      font-family: Alibaba PuHuiTi 2-65 Medium, Alibaba PuHuiTi 20;
      color: #000000;
    }
  }

  .text-input {
    margin-bottom: 0.6rem;
    :deep .van-field {
      --van-field-error-message-color: red;
      --van-cell-line-height: 0.68rem;
      .van-field__control {
        &::placeholder {
          font-size: 0.32rem;
          font-family: PingFang SC-Medium, PingFang SC;
          font-weight: 500;
          color: #999999;
        }
      }
    }

    .username {
      border-bottom: 0.01rem solid #e5e5e5;
      margin-bottom: 0.5rem;
    }
    .password {
      border-bottom: 0.01rem solid #e5e5e5;
    }
    .code {
      border-bottom: 0.01rem solid #e5e5e5;
      .VCode {
        min-width: 2rem;
        height: 0.68rem;
        background: $themeColor;
        border-radius: 0.4rem;
        font-family: PingFang SC-Medium, PingFang SC;
        font-weight: 500;
        color: #ffffff;
        &.disabled {
          background: #dddddd;
        }
      }
    }
  }

  .buts {
    :deep .van-button--disabled {
      background: #dddddd;
      border-color: #dddddd;
      opacity: 1;
    }
  }
}
</style>