<template>
  <div class="index bsbb">
    <div class="fsb">
      <van-button type="success" @click="type = 0">关闭识别</van-button>
      <van-button type="success" @click="type = 1">点击扫码识别</van-button>
      <van-button type="success" @click="type = 2">识别二维码</van-button>
    </div>
    <div style="width:100vw;height:100vw;">
      <QRcodeScanning :type="type" @scanCodeOk="scanCodeOk" />
    </div>
  </div>

</template>
<script lang="ts">
export default {
  name: "index",
};
</script>

<script setup lang="ts">
/**
 * 依赖引入
 */
import {
  ref,
  onMounted,
  getCurrentInstance,
  reactive,
  toRefs,
  computed,
  watch,
} from "vue";

// vuex使用
import { useStore } from "vuex";
const store = useStore();

// route使用
import { useRouter } from "vue-router";
const router = useRouter();

// vant使用
import { Toast, Dialog } from "vant";

// 使用全局方法
const _this: any = getCurrentInstance();
const {
  $getFileUrl,
  $formatDate,
  $specifyDays,
  $specifyMonths,
  $moneyConversion,
  $getalldays,
  $getDateArry,
  $deepClone,
  $toDecimal2,
  $parseTime,
  $tenThousandConversion,
} = _this.appContext.config.globalProperties;

/**
 * 接口引入
 */

/**
 * 组件引入
 */
import QRcodeScanning from "@/components/QRcodeScanning/index.vue";

/**
 * 变量区
 */
const type = ref(0);

/**
 * 方法区
 */
// 二维码扫描成功
function scanCodeOk(data: object) {
  console.log(data);
}

// 页面跳转事件
function pageJump(path = "", obj: any = {}) {
  router.push({
    path,
    query: {
      data: JSON.stringify(obj),
    },
  });
}

// 页面刷新事件
function refreshFn() {
  router.go(0);
}

// 钩子函数
onMounted(async () => {});

/**
 * 监控区
 */
</script>
<style lang="scss" scoped src="./index.scss" />