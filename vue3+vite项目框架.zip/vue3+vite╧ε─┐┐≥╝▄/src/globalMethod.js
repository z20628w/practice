/**
 * 全局方法定义
 * key : 全局方法名称
 * fn： 全局方法函数
*/
import { deepClone, formatDate, specifyDays, parseTime, getalldays, getDateArry, specifyMonths } from "@/utils/index.js";
import { moneyConversion, toDecimal2, colorTransform, tenThousandConversion } from "@/utils/customMethod.js";

const globalMethod = [
  { //全局文件引入方法
    key: "$getFileUrl",
    fn: (key, url) => {
      let obj = {
        index: new URL(`/src/assets/image/index/${url}`, import.meta.url).href,
        goodsList: new URL(`/src/assets/image/goodsList/${url}`, import.meta.url).href,
      }

      return obj[key]
    }
  },
  { //对象/数据深拷贝
    key: "$deepClone",
    fn: deepClone
  },
  { //时间格式化
    key: "$formatDate",
    fn: formatDate
  },
  { //获取指定日期之前指定天数或者之后指定天数的日期
    key: "$specifyDays",
    fn: specifyDays
  },
  { //获取指定日期的年月日时分秒
    key: "$parseTime",
    fn: parseTime
  },
  { //获取指定月份之前指定月份数或者之后指定月份数的月份
    key: "$specifyMonths",
    fn: specifyMonths
  },
  { //获取选择之间的所有日期
    key: "$getalldays",
    fn: getalldays
  },
  { //获取选择之间的所有月份
    key: "$getDateArry",
    fn: getDateArry
  },
  { //单位转换(元 - 分)
    key: "$moneyConversion",
    fn: moneyConversion
  },
  { //保留指定位小数
    key: "$toDecimal2",
    fn: toDecimal2
  },
  { //十六进制颜色转为rgba
    key: "$colorTransform",
    fn: colorTransform
  },
  { //数值单位转换
    key: "$tenThousandConversion",
    fn: tenThousandConversion
  },
];


export default globalMethod