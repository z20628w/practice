/**
 * @param {string} path
 * @returns {Boolean}
 */
export function isExternal(path) {
    return /^(https?:|mailto:|tel:)/.test(path);
}

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function validUsername(str) {
    const valid_map = ['admin', 'editor'];
    return valid_map.indexOf(str.trim()) >= 0;
}

/**
 * @param {string} url
 * @returns {Boolean}
 */
export function validURL(url) {
    const reg = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/;
    return reg.test(url);
}

/**
 * 编号/账号验证，只能为数字字母
 * @param {string} str
 * @returns {Boolean}
 */
export let accountPattern = /^[A-Za-z\d]+$/;
export function validaccount(str) {
    return accountPattern.test(str);
}

/**
 * 正整数验证
 * @param {string} str
 * @returns {Boolean}
 */
export let positiveIntegerPattern = /^[0-9]*[1-9][0-9]*$/;
export function validPositiveInteger(str) {
    return positiveIntegerPattern.test(str);
}

/**
 * 非负整数验证
 * @param {string} str
 * @returns {Boolean}
 */
export let nonnegativeIntegerPattern = /^\d*$/;
export function validNonnegativeInteger(str) {
    return nonnegativeIntegerPattern.test(str);
}

/**
 * @param {string} email
 * @returns {Boolean}
 */
export let emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export function validEmail(email) {
    return emailPattern.test(email);
}

/**
 * @param {string} mobile
 * @returns {Boolean}
 */
export let mobilePattern = /^1[3-9]\d{9}$/;
export function validmobile(mobile) {
    return mobilePattern.test(mobile);
}

/**
 * 排序值验证 区间:(1~99999)
 * @param {string} sort
 * @returns {Boolean}
*/
export let sortPattern = /^[1-9]\d{0,4}$/;
export function validsort(sort) {
    return sortPattern.test(sort);
}

/**
 * 价格验证 十万以内保留两位小数
 * @param {string} Price
 * @returns {Boolean}
*/
export let pricePattern = /(^\d{1,5}$)|(^\d{1,5}\.\d{1,2}$)/;
export function validPrice(Price) {
    return pricePattern.test(Price);
}

/**
 * 密码验证
 * @param {string} pass
 * @returns {Boolean}
*/
export let passPattern = /^[\da-zA-Z\._*]{6,18}$/;
export function validpass(pass) {
    return passPattern.test(pass);
}

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function isString(str) {
    if (typeof str === 'string' || str instanceof String) {
        return true;
    }
    return false;
}

/**
 * @param {Array} arg
 * @returns {Boolean}
 */
export function isArray(arg) {
    if (typeof Array.isArray === 'undefined') {
        return Object.prototype.toString.call(arg) === '[object Array]';
    }
    return Array.isArray(arg);
}
