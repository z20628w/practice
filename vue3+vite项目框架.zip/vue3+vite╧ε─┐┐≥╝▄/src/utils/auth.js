import Cookies from 'js-cookie'
import { encrypt, decrypt } from "./jsencrypt"

/**
 * token存储
*/
let token = "SLSK-TOKEN"

export function getToken () {
    // return decrypt(Cookies.get(token))
    return Cookies.get(token)
}

export function setToken (val, time = 1) {
    /**
     * time：存储时间,单位(天)
    */

    let times = new Date().getTime() + (time * 1000 * 60 * 60 * 24);

    // return Cookies.set(token, encrypt(val), { expires: new Date(times) })
    return Cookies.set(token, val, { expires: new Date(times) })
}

export function removeToken () {
    return Cookies.remove(token)
}

/**
 * userinfo存储
*/
let userinfo = "SLSK-USERINFO"

export function getUserinfo () {
    return Cookies.get(userinfo)
}

export function setUserinfo (val, time = 1) {
    /**
     * time：存储时间,单位(天)
    */

    let times = new Date().getTime() + (time * 1000 * 60 * 60 * 24);

    return Cookies.set(userinfo, val, { expires: new Date(times) })
}

export function removeUserinfo () {
    return Cookies.remove(userinfo)
}

/* 存储值到浏览器缓存 -- localStorage */

// 获取指定key在浏览器localStorage中的值
export function getLocalStorageCache (key) {
    return localStorage.getItem(key)
}

// 设置指定key在浏览器localStorage中的值
export function setLocalStorageCache (key, data) {
    return localStorage.setItem(key, data)
}

// 删除指定key在浏览器localStorage中的缓存
export function removeLocalStorageCache (key) {
    return localStorage.removeItem(key)
}

/* 存储值到浏览器缓存 -- sessionStorage */

// 获取指定key在浏览器sessionStorage中的值
export function getSessionStorageCache (key) {
    return sessionStorage.getItem(key)
}

// 设置指定key在浏览器sessionStorage中的值
export function setSessionStorageCache (key, data) {
    return sessionStorage.setItem(key, data)
}

// 删除指定key在浏览器sessionStorage中的缓存
export function removeSessionStorageCache (key) {
    return sessionStorage.removeItem(key)
}