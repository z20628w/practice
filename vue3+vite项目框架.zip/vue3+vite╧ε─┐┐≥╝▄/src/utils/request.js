import axios from 'axios';
import store from '@/store';
import { getToken, removeToken, removeUserinfo } from '@/utils/auth';
import router from '@/router';
import { Toast } from "vant";
// 请求的地址方法
function AddressEdit (type = 1) {
    let path = "";
    switch (type) {
        case 0:
            path = import.meta.env.VITE_APP_BASE_API
            break;
        default:
            path = '';
            break;
    }

    return path || '';
}

let loadObj = {}; //保存需要loading加载动画的接口

let lengths = () => Object.keys(loadObj).length; // 获取当前还有多少需要loading加载动画

let times = null;//定时器，用于存储接口报错后执行的loading清除事件

axios.defaults.headers['Content-Type'] = 'application/json;charset=utf-8';
// 创建axios实例
const service = axios.create({
    // axios中请求配置有baseURL选项，表示请求URL公共部分
    baseURL: "",
    // 超时
    timeout: 0
});
// request拦截器
service.interceptors.request.use(config => {
    // 开启全局的加载动画
    if (lengths()) store.dispatch('settings/changeSetting', {
        key: 'loading',
        value: true
    });

    // 是否需要设置 token
    const isToken = (config.headers || {}).isToken === false;
    if (getToken() && !isToken) {
        config.headers['Authorization'] = getToken(); // 让每个请求携带自定义token 请根据实际情况自行修改
    }

    config.headers['Cache-Control'] = "no-cache"; // 所有请求都不缓存

    // get请求映射params参数
    if (config.method === 'get' && config.params) {
        let url = config.url + '?';
        for (const propName of Object.keys(config.params)) {
            const value = config.params[propName];
            var part = encodeURIComponent(propName) + "=";
            if (value !== null && typeof (value) !== "undefined") {
                if (typeof value === 'object') {
                    for (const key of Object.keys(value)) {
                        let params = propName + '[' + key + ']';
                        var subPart = encodeURIComponent(params) + "=";
                        url += subPart + encodeURIComponent(value[key]) + "&";
                    }
                } else {
                    url += part + encodeURIComponent(value) + "&";
                }
            }
        }
        url = url.slice(0, -1);
        config.params = {};
        config.url = url;
    }
    return config;
}, error => {
    console.log(error);
    Promise.reject(error);
});

// 响应拦截器
service.interceptors.response.use(res => {
    let url = res.config.url.indexOf('?') == -1 ? res.config.url : res.config.url.slice(0, res.config.url.indexOf('?'));

    // 响应成功就删除loadObj中对应的url,将那个url对应的值设置为undefined,然后根据JSON.stringify的特性将其删除
    loadObj[url] = undefined;
    loadObj = JSON.parse(JSON.stringify(loadObj));

    // 隐藏全局的加载动画
    if (!lengths()) store.dispatch('settings/changeSetting', {
        key: 'loading',
        value: false
    });

    let obj = {}

    if (Object.prototype.toString.call(res.data) == "[object Object]") {
        obj = { ...res.data, ...{ headers: { ...res.headers } } }
    } else {
        obj = { ...res }
    }

    if (res.data.result == 302) {
        // 更新token与用户信息
        store.dispatch('user/changeUser', {
            key: 'token',
            value: null
        });
        store.dispatch('user/changeUser', {
            key: 'userinfo',
            value: null
        });
        removeToken();
        removeUserinfo();

        Toast.fail('登录失效，请重新登录');

        router.go({ name: 'login' });
    }

    return obj;

},
    (error) => {
        let { message } = error;

        // 获取错误信息
        if (message.substr(message.length - 3) == 302) {
            // MessageBox.confirm('登录状态已过期，您可以继续留在该页面，或者重新登录', '系统提示', {
            //     confirmButtonText: '重新登录',
            //     cancelButtonText: '取消',
            //     type: 'warning'
            // }
            // ).then(() => {
            // 更新token与用户信息
            store.dispatch('user/changeUser', {
                key: 'token',
                value: null
            });
            store.dispatch('user/changeUser', {
                key: 'userinfo',
                value: null
            });
            removeToken();
            removeUserinfo();

            router.go({ name: 'login' });
            // });
        } else if (message == "Network Error") {
            message = "后端接口连接异常";
        } else if (message.includes("timeout")) {
            message = "系统接口请求超时";

        } else if (message.includes("Request failed with status code")) {
            message = "系统接口" + message.substr(message.length - 3) + "异常";
        }

        clearTimeout(times);
        times = setTimeout(() => {
            loadObj = {};
            // 隐藏全局的加载动画
            store.dispatch('settings/changeSetting', {
                key: 'loading',
                value: false
            });
        }, 1000);

        return Promise.reject(error);
    }
);

export default function (data, load = true, baseURLType = 0) {
    /**
   * data 请求数据
   * load:当前接口是否开启全局加载
   * baseURLType 请求地址 0 -- import.meta.env.VITE_APP_BASE_API
   */

    // 对多地址请求接口进行请求地址重置
    data.url = AddressEdit(baseURLType) + data.url;

    if (load) loadObj[data.url] = load;
    return service(data);
}
