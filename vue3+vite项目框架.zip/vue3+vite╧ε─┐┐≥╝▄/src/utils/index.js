/**
 * 时间格式化
 */
export function formatDate (cellValue, sepa = "-", isTime = true) {
    /**
     * cellValue:需要解析的时间或者时间戳
     * sepa：分隔符
     * isTime：是否需要时分秒
    */
    if (cellValue && (typeof cellValue == "string")) cellValue = cellValue.replace(/-/g, "/"); //兼容苹果浏览器时间格式
    if (cellValue == null || cellValue == "") return "";
    var date = new Date(cellValue);
    var year = date.getFullYear();
    var month = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
    var day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var hours = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    var minutes = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    var seconds = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();

    if (isTime) return `${year}${sepa}${month}${sepa}${day} ${hours}:${minutes}:${seconds}`;
    else return `${year}${sepa}${month}${sepa}${day}`;
}

/**
 * 获取指定日期之前指定天数或者之后指定天数的日期
*/
export function specifyDays (dd = "", dadd = 0, sepa = "-", isTime = true) {
    /**
     * dd:指定日期，不传或者错误传法都为当天的日期，
     * dadd:指定的天数(必须为整数)
     *      负数为指定日期之前几天的日期
     *      正数为指定日期之后几天的日期
     * sepa：分隔符
     * isTime：是否需要时分秒
    */
    if (dd && (typeof dd == "string")) dd = dd.replace(/-/g, "/"); //兼容苹果浏览器时间格式
    // 获取指定日期
    let a = null;
    a = dd ? new Date(dd) : new Date();
    if (a == "Invalid Date") a = new Date();

    a = a.valueOf();
    a = a + dadd * 24 * 60 * 60 * 1000
    a = new Date(a)

    return formatDate(a, sepa, isTime)
}

/**
 * 获取指定月份之前指定月份数或者之后指定月份数的月份
*/
export function specifyMonths (mm = "", num = 0, sepa = "-",) {
    /**
     * mm:指定月份，不传或者错误传法都为当天的月份，
     * num:指定的月份数(必须为整数)
     *      负数为指定月份之前几天的月份
     *      正数为指定月份之后几天的月份
    */
    num = parseInt(num);

    if (mm && (typeof mm == "string")) mm = mm.replace(/-/g, "/"); //兼容苹果浏览器时间格式
    // 获取指定月份
    let a = null;
    a = mm ? new Date(mm) : new Date();
    if (a == "Invalid Date") a = new Date();

    a.setMonth(a.getMonth() + num)
    a.toLocaleDateString()
    return parseTime(a)
}

/**
 * 获取指定日期的年月日时分秒
*/
export function parseTime (time) {
    if (arguments.length === 0 || !time) {
        return null;
    }
    let date;
    if (typeof time === 'object') {
        date = time;
    } else {
        if ((typeof time === 'string') && (/^[0-9]+$/.test(time))) {
            time = parseInt(time);
        } else if (typeof time === 'string') {
            time = time.replace(new RegExp(/-/gm), '-');
        }
        if ((typeof time === 'number') && (time.toString().length === 10)) {
            time = time * 1000;
        }
        date = new Date(time);
    }
    const formatObj = {
        y: (date.getFullYear()).toString(),
        m: (date.getMonth() + 1).toString(),
        d: (date.getDate()).toString(),
        h: (date.getHours()).toString(),
        i: (date.getMinutes()).toString(), //分
        s: (date.getSeconds()).toString(),//秒
        a: (date.getDay()).toString(),//周几
        ds: "0",//当月总天数
    };

    // 获取当月总天数
    formatObj.ds = new Date(formatObj.y, formatObj.m, 0).getDate().toString();

    // 补零
    formatObj.m = formatObj.m < 10 ? `0${formatObj.m}` : formatObj.m;
    formatObj.d = formatObj.d < 10 ? `0${formatObj.d}` : formatObj.d;
    formatObj.h = formatObj.h < 10 ? `0${formatObj.h}` : formatObj.h;
    formatObj.i = formatObj.i < 10 ? `0${formatObj.i}` : formatObj.i;
    formatObj.s = formatObj.s < 10 ? `0${formatObj.s}` : formatObj.s;

    return formatObj;
}

/**
    * 获取选择之间的所有日期
    * start:开始时间   ex:2021-08-02
    * end：结束时间   ex:2021-08-17
    * */

export function getalldays (start, end, sepa = "-") {
    let date1 = new Date(start);
    let date2 = new Date(end);
    if (date1 == "Invalid Date") date1 = new Date();
    if (date2 == "Invalid Date") date2 = new Date();

    var startTime = date1.getTime();
    var endTime = date2.getTime();

    let arr = []
    for (var k = startTime; k <= endTime;) {
        arr.push(formatDate(parseInt(k), sepa, false))
        k = k + 24 * 60 * 60 * 1000;
    }

    return arr;
}

/**
    * 获取选择之间的所有月份
    * start:开始时间   ex:2021-08
    * end：结束时间   ex:2022-08
    * */

export function getDateArry (startDate, endDate) {
    let date1 = new Date(startDate);
    let date2 = new Date(endDate);
    if (date1 == "Invalid Date") date1 = new Date();
    if (date2 == "Invalid Date") date2 = new Date();

    var d1 = `${(date1.getFullYear()).toString()}-${(date1.getMonth() + 1).toString()}`;
    var d2 = `${(date2.getFullYear()).toString()}-${(date2.getMonth() + 1).toString()}`;

    var dateArry = new Array();
    var s1 = d1.split("-");
    var s2 = d2.split("-");
    var mCount = 0;
    if (parseInt(s1[0]) < parseInt(s2[0])) {
        mCount = (parseInt(s2[0]) - parseInt(s1[0])) * 12 + parseInt(s2[1]) - parseInt(s1[1]) + 1;
    } else {
        mCount = parseInt(s2[1]) - parseInt(s1[1]) + 1;
    }
    if (mCount > 0) {
        var startM = parseInt(s1[1]);
        var startY = parseInt(s1[0]);
        for (var i = 0; i < mCount; i++) {
            if (startM < 12) {
                dateArry[i] = startY + "-" + (startM > 9 ? startM : "0" + startM);
                startM += 1;
            } else {
                dateArry[i] = startY + "-" + (startM > 9 ? startM : "0" + startM);
                startM = 1;
                startY += 1;
            }
        }
    }
    return dateArry;
}

/**
 * 获取地址参数
 * @param {string} url
 * @returns {Object}
 */
export function getQueryObject (url) {
    url = url == null ? window.location.href : url;
    const search = url.substring(url.lastIndexOf('?') + 1);
    const obj = {};
    const reg = /([^?&=]+)=([^?&=]*)/g;
    search.replace(reg, (rs, $1, $2) => {
        const name = decodeURIComponent($1);
        let val = decodeURIComponent($2);
        val = String(val);
        obj[name] = val;
        return rs;
    });
    return obj;
}

/**
 * 返回utf8字符串的字节长度
 * @param {string} input value
 * @returns {number} output value
 */
export function byteLength (str) {
    // returns the byte length of an utf8 string
    let s = str.length;
    for (var i = str.length - 1; i >= 0; i--) {
        const code = str.charCodeAt(i);
        if (code > 0x7f && code <= 0x7ff) s++;
        else if (code > 0x7ff && code <= 0xffff) s += 2;
        if (code >= 0xDC00 && code <= 0xDFFF) i--;
    }
    return s;
}

/**
 * Merges two objects, giving the last one precedence
 * @param {Object} target
 * @param {(Object|Array)} source
 * @returns {Object}
 */
export function objectMerge (target, source) {
    if (typeof target !== 'object') {
        target = {};
    }
    if (Array.isArray(source)) {
        return source.slice();
    }
    Object.keys(source).forEach(property => {
        const sourceProperty = source[property];
        if (typeof sourceProperty === 'object') {
            target[property] = objectMerge(target[property], sourceProperty);
        } else {
            target[property] = sourceProperty;
        }
    });
    return target;
}

/**
 * 给标签元素添加class
 * @param {HTMLElement} element
 * @param {string} className
 */
export function toggleClass (element, className) {
    if (!element || !className) {
        return;
    }
    let classString = element.className;
    const nameIndex = classString.indexOf(className);
    if (nameIndex === -1) {
        classString += '' + className;
    } else {
        classString =
            classString.substr(0, nameIndex) +
            classString.substr(nameIndex + className.length);
    }
    element.className = classString;
}

/**
 * 节流事件
 * @param {Function} func
 * @param {number} wait
 * @param {boolean} immediate
 * @return {*}
 */
export function debounce (func, wait, immediate) {
    let timeout, args, context, timestamp, result;

    const later = function () {
        // 据上一次触发时间间隔
        const last = +new Date() - timestamp;

        // 上次被包装函数被调用时间间隔 last 小于设定时间间隔 wait
        if (last < wait && last > 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
            if (!immediate) {
                result = func.apply(context, args);
                if (!timeout) context = args = null;
            }
        }
    };

    return function (...args) {
        context = this;
        timestamp = +new Date();
        const callNow = immediate && !timeout;
        // 如果延时不存在，重新设定延时
        if (!timeout) timeout = setTimeout(later, wait);
        if (callNow) {
            result = func.apply(context, args);
            context = args = null;
        }

        return result;
    };
}

/**
 * 深拷贝
 * This is just a simple version of deep copy
 * Has a lot of edge cases bug
 * If you want to use a perfect deep copy, use lodash's _.cloneDeep
 * @param {Object} source
 * @returns {Object}
 */
export function deepClone (source) {
    if (!source && typeof source !== 'object') {
        throw new Error('error arguments', 'deepClone');
    }
    const targetObj = source.constructor === Array ? [] : {};
    Object.keys(source).forEach(keys => {
        if (source[keys] && typeof source[keys] === 'object') {
            targetObj[keys] = deepClone(source[keys]);
        } else {
            targetObj[keys] = source[keys];
        }
    });
    return targetObj;
}

/**
 * 数组去重
 * @param {Array} arr
 * @returns {Array}
 */
export function uniqueArr (arr) {
    return Array.from(new Set(arr));
}

/**
 * 创建一个唯一字符串
 * @returns {string}
 */
export function createUniqueString () {
    const timestamp = +new Date() + '';
    const randomNum = parseInt((1 + Math.random()) * 65536) + '';
    return (+(randomNum + timestamp)).toString(32);
}

/**
 * 判断元素是否存在class
 * Check if an element has a class
 * @param {HTMLElement} elm
 * @param {string} cls
 * @returns {boolean}
 */
export function hasClass (ele, cls) {
    return !!ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
}

/**
 * 元素添加class
 * Add class to element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function addClass (ele, cls) {
    if (!hasClass(ele, cls)) ele.className += ' ' + cls;
}

/**
 * 元素删除class
 * Remove class from element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function removeClass (ele, cls) {
    if (hasClass(ele, cls)) {
        const reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
        ele.className = ele.className.replace(reg, ' ');
    }
}

// 获取字符串指定字符在字符串中第n次出现的位置
export function findNum (str, cha, num) {
    var x = str.indexOf(cha);
    for (var i = 0; i < num; i++) {
        x = str.indexOf(cha, x + 1);
    }
    return x;
}

// 首字母大小
export function titleCase (str) {
    return str.replace(/( |^)[a-z]/g, L => L.toUpperCase());
}

// 下划转驼峰
export function camelCase (str) {
    return str.replace(/-[a-z]/g, str1 => str1.substr(-1).toUpperCase());
}

export function isNumberStr (str) {
    return /^[+-]?(0|([1-9]\d*))(\.\d+)?$/g.test(str);
}

