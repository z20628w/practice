﻿/**
 * 通用js方法封装处理
 */

import { deepClone } from "@/utils/index";

// 日期格式化
export function parseTime (time, pattern) {
    if (arguments.length === 0 || !time) {
        return null;
    }
    const format = pattern || '{y}-{m}-{d} {h}:{i}:{s}';
    let date;
    if (typeof time === 'object') {
        date = time;
    } else {
        if ((typeof time === 'string') && (/^[0-9]+$/.test(time))) {
            time = parseInt(time);
        } else if (typeof time === 'string') {
            time = time.replace(new RegExp(/-/gm), '-');
        }
        if ((typeof time === 'number') && (time.toString().length === 10)) {
            time = time * 1000;
        }
        date = new Date(time);
    }
    const formatObj = {
        y: date.getFullYear(),
        m: date.getMonth() + 1,
        d: date.getDate(),
        h: date.getHours(),
        i: date.getMinutes(),
        s: date.getSeconds(),
        a: date.getDay()
    };
    const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
        let value = formatObj[key];
        // Note: getDay() returns 0 on Sunday
        if (key === 'a') {
            return ['日', '一', '二', '三', '四', '五', '六'][value];
        }
        if (result.length > 0 && value < 10) {
            value = '0' + value;
        }
        return value || 0;
    });
    return time_str;
}


// 通用下载方法2 必须为后台返回的blob数据
export function download_blob (data, fileName) {
    let url = window.URL.createObjectURL(new Blob([data]));
    let a = document.createElement('a');
    a.setAttribute('href', url);
    a.setAttribute('download', fileName);
    a.click(); //强制触发a标签事件
    a = null;
}

// 通用下载方法3 使用href下载
export function download_href (url = "", data = {}) {
    if (!(data instanceof Object)) return console.log('您传的参数不是对象类型');
    let parems = '?';
    Object.entries(data).forEach(item => {
        parems += `${item[0]}=${item[1]}&`;
    });
    window.location.href = url + parems;
}

// 转换字符串，undefined,null等转化为""
export function praseStrEmpty (str) {
    if (!str || str == "undefined" || str == "null") {
        return "";
    }
    return str;
}

/**
 * 构造树型结构数据
 * @param {*} data 数据源
 * @param {*} id id字段 默认 'id'
 * @param {*} parentId 父节点字段 默认 'parentId'
 * @param {*} children 孩子节点字段 默认 'children'
 */
export function handleTree (data, id, parentId, children) {
    let config = {
        id: id || 'id',
        parentId: parentId || 'parentId',
        childrenList: children || 'children'
    };

    var childrenListMap = {};
    var nodeIds = {};
    var tree = [];

    for (let d of data) {
        let parentId = d[config.parentId];
        if (childrenListMap[parentId] == null) {
            childrenListMap[parentId] = [];
        }
        nodeIds[d[config.id]] = d;
        childrenListMap[parentId].push(d);
    }

    for (let d of data) {
        let parentId = d[config.parentId];
        if (nodeIds[parentId] == null) {
            tree.push(d);
        }
    }

    for (let t of tree) {
        adaptToChildrenList(t);
    }

    function adaptToChildrenList (o) {
        if (childrenListMap[o[config.id]] !== null) {
            o[config.childrenList] = childrenListMap[o[config.id]];
        }
        if (o[config.childrenList]) {
            for (let c of o[config.childrenList]) {
                adaptToChildrenList(c);
            }
        }
    }
    return tree;
}

// 判断是否为链接
export function isUrl (str) {
    var v = new RegExp('^(?!mailto:)(?:(?:http|https|ftp)://|//)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$', 'i');
    return v.test(str);
}

// 时间间隔天数获取
export function daysBetween (sDate1, sDate2) {
    if (sDate1 && (typeof sDate1 == "string")) sDate1 = sDate1.replace(/-/g, "/"); //兼容苹果浏览器时间格式
    if (sDate2 && (typeof sDate2 == "string")) sDate2 = sDate2.replace(/-/g, "/"); //兼容苹果浏览器时间格式

    //Date.parse() 解析一个日期时间字符串，并返回1970/1/1 午夜距离该日期时间的毫秒数
    var time1 = Date.parse(new Date(sDate1));
    var time2 = Date.parse(new Date(sDate2));
    var nDays = Math.abs(parseInt((time2 - time1) / 1000 / 3600 / 24));
    return nDays;
}

// 去除对象中的空值
export function obj_no_null (data = {}) {
    let obj = {};
    Object.entries(data).forEach(item => {
        if (item[1] !== '' && item[1] !== undefined && item[1] !== null) {
            obj[item[0]] = item[1];
        }
    });
    return obj;
}

// 数组公共递归事件
export function commonRecursionFn (arr = [], fn = () => { }, parentItem = {}, level = 1) {
    /**
     * arr : 需要递归的数组
     *
     * fn : 递归操作函数
     *      参数:
     *            item:当前对象 index:当前下标 list:当前所属数组 parentItem:当前所属数组的父级 level:当前递归层级
     *
     * parentItem：当前所属数组的父级
     
     * level : 当前层级
     */
    let data = deepClone(arr);
    data = data.filter((item, index, list) => {
        item = fn(item, index, list, parentItem, level) || undefined;
        if (item && item.children && item.children.length) {
            item.children = commonRecursionFn(
                item.children,
                fn,
                item,
                level + 1
            );
        }
        else {
            item && (item.children = undefined);
        }

        return !!item;
    });

    return data;
};
