/**
 * 自定义方法
*/

// 页面不刷新修改地址栏参数
export function editUrlQuery (query = {}) {
  let parm = Object.entries(query)
    .map((item) => `${item[0]}=${item[1]}&`)
    .join("");

  parm = parm.substr(0, parm.length - 1);

  let href = `${location.origin}/#${this.$route.path}?${parm}`;

  window.history.replaceState("", "", href);
};

// 保留指定位小数
export function toDecimal2 (x = 0, n = 2, isZero = false) {
  /**
   * x:需要改变的数字
   * n:需要保留的位数
   * isZero：如果小数点最后有零，是否保留
  */

  // 将数据转换为数组
  var f = parseFloat(x);

  // 判断舒服为数字
  if (isNaN(f)) {
    f = 0;
  }

  // 转换为字符串
  var s = f.toString();

  //用小数点将值隔开
  var rs = s.split(".");

  // 判断是否有小数点
  if (rs.length < 2) {

    // 没小数就添加指定位数的0
    rs[1] = "".padEnd(n, '0');

  } else {
    // 有小数点

    // 判断小数位数是否比需要保留的位数多
    let len = rs[1] ? rs[1].length : 0;//小数点后的值的长度
    if (n <= len) {
      // 只截取两位数
      rs[1] = rs[1].substr(0, n);
    } else {
      //差的几位用0填补
      rs[1] = rs[1].padEnd(n, '0');
    }
  }

  let num = n > 0 ? rs.join('.') : rs[0];

  // 不保留小数点最后的零
  if (!isZero) {
    num = Number(num);
  }

  return num;

}

// 单位转换(元 - 分)
export function moneyConversion (n = 0, b = false) {
  /**
   * n:需要改变的数字
   * b:是否将元转换为分
   *    true:元 ==》 分
   *    false:分 ==》 元
  */

  let num = isFinite(n) ? Number(n || '0') : 0;

  if (b) num = num * 1000 / 10;//乘以一千然后除以10是为了解决精度问题 如 ： 9.7 * 100 == 969.9999999999999
  else num = num / 100;

  return num;
}

// 十六进制颜色转为rgba
export function colorTransform (sHex, alpha = 1) {
  let reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/
  /* 16进制颜色转为RGB格式 */
  let sColor = sHex.toLowerCase()
  if (sColor && reg.test(sColor)) {
    if (sColor.length === 4) {
      let sColorNew = '#'
      for (let i = 1; i < 4; i += 1) {
        sColorNew += sColor.slice(i, i + 1).concat(sColor.slice(i, i + 1))
      }
      sColor = sColorNew
    }
    //  处理六位的颜色值
    let sColorChange = []
    for (let i = 1; i < 7; i += 2) {
      // eslint-disable-next-line radix
      sColorChange.push(parseInt(`0x${sColor.slice(i, i + 2)}`))
    }
    return `rgba(${sColorChange.join(',')},${alpha})`
  }
  return sColor
}

// 数值单位转换
export function tenThousandConversion (n) {
  let obj = {
    value: n,//数值
    unit: ''//数值单位
  }

  // 当数字大于十万小于一个亿时
  if (obj.value > 100000 && obj.value < 100000000) {
    obj.value = obj.value / 10000;
    obj.unit = 'w';//单位:万
  } else if (obj.value >= 100000000) {
    obj.value = obj.value / 100000000;
    obj.unit = '亿';
  }

  return obj

}




