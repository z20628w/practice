<template>
  <div class="QRcodeScanning">
    <!-- 访问设备相机并连续扫描传入的帧。 -->
    <div class="stream" v-if="type == 1">
      <!-- <qr-stream @decode="onDecode">
        <div class="streamCont bsbb fcc">
          <slot>
            <div class="scanningImg"></div>
          </slot>
        </div>
      </qr-stream> -->
      <scanning @stepFn="scanning_stepFn" @decode="onDecode" />
    </div>

    <!-- 选择文件进行二维码解析 -->
    <div class="capture" v-else-if="type == 2">
      <qr-capture @decode="onDecode" class="capture-dom"></qr-capture>
      <slot>
        <div class="captureCont bsbb fcc">
          点击选择二维码图片进行解析
        </div>
      </slot>
    </div>

    <!-- 创建一个拖放区域以扫描所有放置的文件 -->
    <div class="dropzone" v-else-if="type == 3">
      <qr-dropzone @decode="onDecode">
        <!-- <slot> -->
        <div class="dropzoneCont bsbb fcc">
          请将二维码图片拖入进行解析
        </div>
        <!-- </slot> -->
      </qr-dropzone>
    </div>
  </div>
</template>
<script lang="ts">
export default {
  name: "QRcodeScanning",
};
</script>
<script setup  lang="ts">
/**
*
依赖引入
*
*/
import {
  ref,
  toRefs,
  reactive,
  onMounted,
  getCurrentInstance,
  defineProps,
  defineEmits,
} from "vue";

// vuex使用
import { useStore } from "vuex";
const store = useStore();

// route使用
import { useRouter } from "vue-router";
const router = useRouter();

// 使用全局方法
const _this: any = getCurrentInstance();
const { $getFileUrl } = _this.appContext.config.globalProperties;

// 接收传入的值
const props = defineProps({
  //二维码扫码模式 1 -- 实时扫码  2 -- 选择文件进行二维码解析 3 -- 拖动文件进入指定区域进行二维码解析
  type: {
    type: Number,
    default: 1,
  },
});
const { type } = toRefs(props);

// 初始化emit事件
const emit = defineEmits(["scanCodeOk", "scanning_stepFn"]);

/**
*
组件引入
*
*/
// 二维码扫描组件
import { QrStream, QrCapture, QrDropzone } from "vue3-qr-reader";
import scanning from "./scanning.vue";

/**
*
接口引入
*
*/

/**
*
变量区
*
*/
const state = reactive({
  code: null,
});
const { code } = toRefs(state);

/**
*
方法区
*
*/
// 扫描二维码当前到达的步骤
function scanning_stepFn(row) {
  emit("scanning_stepFn", row);
}

// 二维码解析回调事件
const onDecode = (data: any) => {
  state.code = data;

  emit("scanCodeOk", { value: data });
};

/**
*
钩子函数
*
*/
onMounted(() => {});
</script>
<style lang="scss" scoped>
.QRcodeScanning {
  width: 100%;
  height: 100%;

  .stream {
    width: 100%;
    height: 100%;

    .qr-stream-wrapper {
      ::deep.qr-stream-camera {
        position: relative;
        &::before {
          content: "正在获取摄像机权限,请稍后...";
          display: block;
          width: 100%;
          height: 100%;
          background: white;
          position: absolute;
          top: 0;
          left: 0;
        }
      }
    }

    .streamCont {
      width: 100%;
      height: 100%;
      .scanningImg {
        width: 50vw;
        height: 50vw;
        position: relative;
        overflow: hidden;
        $bw: 5px; //背景四个角的宽度
        $bh: 20px; //背景四个角的高度
        &::before {
          content: "";
          display: block;
          width: 100%;
          height: 100%;
          background: linear-gradient(to left, $themeBlue, $themeBlue) left top
              no-repeat,
            linear-gradient(to bottom, $themeBlue, $themeBlue) left top
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) right top no-repeat,
            linear-gradient(to bottom, $themeBlue, $themeBlue) right top
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) left bottom
              no-repeat,
            linear-gradient(to bottom, $themeBlue, $themeBlue) left bottom
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) right bottom
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) right bottom
              no-repeat;
          /*设置大小*/
          background-size: $bw $bh, $bh $bw, $bw $bh, $bh $bw;
          box-sizing: border-box;
        }
        &::after {
          content: "";
          display: block;
          width: calc(100% - #{$bw * 2});
          height: 100%;
          background: linear-gradient(
            to bottom,
            transparent 0%,
            transparent calc(100% - 80px),
            $themeBlue 100%,
            transparent calc(100% + 1px),
            transparent 100%
          );
          background-size: 100% 100%;
          background-repeat: no-repeat;
          position: absolute;
          left: $bw;
          top: -110%;
          animation: sm 2s linear infinite;

          @keyframes sm {
            0% {
              top: -110%;
            }
            100% {
              top: 80px;
            }
          }
        }
      }
    }
  }
  .capture {
    position: relative;
    width: 100%;
    height: 100%;
    .capture-dom {
      position: absolute;
      top: 0;
      left: 0;
      display: block;
      width: 100%;
      height: 100%;
      opacity: 0;
    }
    .captureCont {
      width: 100%;
      height: 100%;
      background: $themeBlue;
    }
  }
  .dropzone {
    width: 100%;
    height: 100%;
    & > div {
      width: 100%;
      height: 100%;
      .dropzoneCont {
        width: 100%;
        height: 100%;
        border: 1px dashed $themeBlue;
      }
    }
  }
}
</style>