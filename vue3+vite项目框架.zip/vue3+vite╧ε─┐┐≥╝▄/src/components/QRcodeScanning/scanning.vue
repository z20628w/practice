<template>
  <div class="scanning">
    <div class="page">
      <video ref="QRCodeRecognition" id="QRCodeRecognition" class="video vjs-fluid" autoplay></video>

      <!-- 当前步骤 -->
      <div v-if="[-1,0,1,2,3].includes(stepData.setpActive)" class="currentSetps fs28 fcc">
        {{stepData[`setp_${stepData.setpActive}`].text}}
      </div>

      <!-- 扫码动画 -->
      <div v-if="[4,5,6].includes(stepData.setpActive)" class="QRCodeAnimation fcc">
        <div class="scanningImg"></div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
export default {
  name: "scanning",
};
</script>
<script setup lang="ts">
/**
*
依赖引入
*
*/
import {
  ref,
  toRefs,
  reactive,
  onMounted,
  onBeforeUnmount,
  getCurrentInstance,
  defineProps,
  defineEmits,
  watch,
} from "vue";

// vuex使用
import { useStore } from "vuex";
const store = useStore();

// route使用
import { useRouter } from "vue-router";
const router = useRouter();

// 使用全局方法
const _this: any = getCurrentInstance();
const { $getFileUrl, $deepClone } = _this.appContext.config.globalProperties;

// 接收传入的值
const props = defineProps({
  // 使用第几个摄像机，从1开始数
  videoCameraIndex: {
    type: Number,
    default: 1,
  },
});
const { videoCameraIndex } = toRefs(props);

// 初始化emit事件
const emit = defineEmits(["decode", "stepFn"]);

// 扫码实例
import { BrowserMultiFormatReader } from "@zxing/library";

/**
*
组件引入
*
*/

/**
*
接口引入
*
*/

/**
*
变量区
*
*/

// 视频实例
const QRCodeRecognition = ref();

// 二维码扫描实例
const codeReader = reactive(new BrowserMultiFormatReader());

// 获取到的摄像机列表
const videoCameraList = reactive([]);

// 扫描出的一/二维码值
const textContent = ref(null);

// 摄像机调用步骤
const stepData = reactive({
  setpActive: -1, //当前步骤
  "setp_-1": {
    step: -1,
    text: "停止使用摄像机",
  },
  setp_0: {
    step: 0,
    text: "正在获取摄像机列表",
  },
  setp_1: {
    step: 1,
    text: "摄像机获取成功",
  },
  setp_2: {
    step: 2,
    text: "摄像机获取失败",
  },
  setp_3: {
    step: 3,
    text: "查找指定摄像机",
  },
  setp_4: {
    step: 4,
    text: "启用摄像头，开始二维码识别",
  },
  setp_5: {
    step: 5,
    text: "二维码识别成功",
  },
  setp_6: {
    step: 6,
    text: "二维码识别失败",
  },
});
/**
*
方法区
*
*/
// 获取摄像机列表
function openScan() {
  useSteps(0);
  codeReader
    .getVideoInputDevices()
    .then((videoInputDevices) => {
      /**
       * videoInputDevices ： 获取到的摄像机列表
       */

      useSteps(1);

      //  保存获取到的摄像机列表
      videoCameraList.length = 0;
      videoCameraList.push(...(videoInputDevices || []));

      useSteps(3);

      // 调用指定摄像头
      decodeFromInputVideoFunc(videoCameraIndex.value);

      // 监听摄像机影像是否开始播放
      videoPlayFn();
    })
    .catch((err) => {
      videoCameraList.length = 0;
      useSteps(2);
    });
}

// 摄像头调用
function decodeFromInputVideoFunc(i = 1) {
  // 如果使用的摄像不存在，就使用第一个摄像机
  if (i > videoCameraList.length) i = 1;
  else if (i < 1) i = 1;

  //  获取指定摄像机id
  let firstDeviceId = videoCameraList[i - 1].deviceId;

  codeReader.reset(); // 重置
  textContent.value = null; // 重置

  // 启用摄像头，开始二维码识别
  codeReader.decodeFromInputVideoDeviceContinuously(
    firstDeviceId,
    "QRCodeRecognition",
    (result, err) => {
      //识别成功
      if (result) {
        // 扫描内容相同就不执行
        if (result.text == textContent.value) return;
        textContent.value = result.text;
        useSteps(5);
      } else if (err && !err) {
        // 识别失败
        useSteps(6);
        textContent.value = "";
      }
    }
  );
}

// 摄像头开始录制监听
function videoPlayFn() {
  codeReader.playVideoOnLoadAsync(QRCodeRecognition.value).then(() => {
    // console.log("开始播放视频");
    useSteps(4);
  });
}

// 关闭摄像头
function clones() {
  if (codeReader) {
    codeReader.reset();
    codeReader.stopStreams();
    useSteps();
  }
}

// 当前摄像机使用步骤修改
function useSteps(num = -1) {
  stepData.setpActive = num;
}

/**
*
钩子函数
*
*/
onMounted(() => {
  openScan();
});

// 在`销毁当前组件前`触发
onBeforeUnmount(() => {
  clones();
});

/**
 * 监听
 */

// 步骤监听
watch(
  stepData,
  (newVal, oldVal) => {
    emit("stepFn", $deepClone(stepData));
  },
  {
    immediate: true,
  }
);

// 扫码监听
watch(
  textContent,
  () => {
    emit("decode", textContent.value);
  },
  {}
);

// 切换摄像头监听
watch(
  videoCameraIndex,
  () => {
    decodeFromInputVideoFunc(videoCameraIndex.value);
  },
  {}
);
</script>
<style lang="scss" scoped>
.scanning {
  width: 100%;
  height: 100%;
  .page {
    position: relative;
    width: 100%;
    height: 100%;
    #QRCodeRecognition {
      object-fit: cover;
      width: 100%;
      height: 100%;
    }
    .currentSetps {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
    .QRCodeAnimation {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      .scanningImg {
        margin-top: -20%;
        width: 50%;
        height: 50%;
        position: relative;
        overflow: hidden;
        $bw: 5px; //背景四个角的宽度
        $bh: 20px; //背景四个角的高度
        &::before {
          content: "";
          display: block;
          width: 100%;
          height: 100%;
          background: linear-gradient(to left, $themeBlue, $themeBlue) left top
              no-repeat,
            linear-gradient(to bottom, $themeBlue, $themeBlue) left top
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) right top no-repeat,
            linear-gradient(to bottom, $themeBlue, $themeBlue) right top
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) left bottom
              no-repeat,
            linear-gradient(to bottom, $themeBlue, $themeBlue) left bottom
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) right bottom
              no-repeat,
            linear-gradient(to left, $themeBlue, $themeBlue) right bottom
              no-repeat;
          /*设置大小*/
          background-size: $bw $bh, $bh $bw, $bw $bh, $bh $bw;
          box-sizing: border-box;
        }
        &::after {
          content: "";
          display: block;
          width: calc(100% - #{$bw * 2});
          height: 100%;
          background: linear-gradient(
            to bottom,
            transparent 0%,
            transparent calc(100% - 80px),
            $themeBlue 100%,
            transparent calc(100% + 1px),
            transparent 100%
          );
          background-size: 100% 100%;
          background-repeat: no-repeat;
          position: absolute;
          left: $bw;
          top: -110%;
          animation: sm 2s linear infinite;

          @keyframes sm {
            0% {
              top: -110%;
            }
            100% {
              top: 80px;
            }
          }
        }
      }
    }
  }
}
</style>