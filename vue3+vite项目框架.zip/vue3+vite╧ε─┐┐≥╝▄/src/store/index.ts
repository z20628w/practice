import { createStore } from 'vuex'
import settings from "./module/settings";
import user from "./module/user";
import getters from "./getters";
export default createStore({
  state: {
    envConfig: import.meta.env
  },
  getters,
  modules: {
    user,
    settings
  }
})