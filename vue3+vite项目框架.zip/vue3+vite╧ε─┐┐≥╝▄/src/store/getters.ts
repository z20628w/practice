const getters = {
  loading: state => state.settings.loading,
  bl: state => state.settings.bl,
  token: state => state.user.token,
  userinfo: state => state.user.userinfo,
  pageCaches: state => state.user.pageCaches,
};
export default getters;
