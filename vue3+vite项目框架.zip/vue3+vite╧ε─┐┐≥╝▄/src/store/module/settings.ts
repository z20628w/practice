import defaultSettings from '@/settings';
const state = {
  // 项目自定义主题参数
  ...defaultSettings
};

const mutations = {
  CHANGE_SETTING: (state, { key, value }) => {
    state[key] = value;
  }
};

const actions = {
  changeSetting({ commit }, data) {
    commit('CHANGE_SETTING', data);
  }
};

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

