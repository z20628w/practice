const state = {
  token: "",

  // 用户详情
  userinfo: null,

  // 需要缓存的页面
  pageCaches: ["index"]
};

const mutations = {
  CHANGE_USER: (state, { key, value }) => {
    state[key] = value;
  },

  // 控制需要缓存的页面
  SET_PAGECACHES: (state, { value, type }) => {
    /**
     * value:需要修改的值
     * type：修改模式 0 - 删除 1 - 新增 2 - 清空
    */

    switch (type) {
      case 0:
        if (state.pageCaches.includes(value)) {
          // 原本存在，就移除
          let index = state.pageCaches.indexOf(value);
          state.pageCaches.splice(index, 1)
        }
        break;
      case 1:
        if (!state.pageCaches.includes(value)) {
          // 原本不在，就添加
          state.pageCaches.push(value)
        }
        break;
      case 2:
        // 清空
        state.pageCaches = [];
        break;
    }

  }
};

const actions = {
  changeUser({ commit }, data) {
    commit('CHANGE_USER', data);
  }
};

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

