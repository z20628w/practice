// 官方文档：https://vue3js.cn/router4/guide/#html
// 引入vue-router对象
import { createRouter, createWebHistory, createWebHashHistory } from "vue-router";
/**
 * 定义路由数组
 */
const routes = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/login/index.vue')
  },
  {
    path: '/',
    name: 'index',
    meta: { title: '首页', cache: true },
    component: () => import('@/views/index/index.vue')
  },
];

/**
 * 创建路由
 */
const router = createRouter({
  // history: createWebHistory("/"),
  history: createWebHashHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {

    if (savedPosition) {
      return savedPosition;
    } else {
      return { top: 0 };
    }
  },
});

/**
 * 输出对象
 */
export default router;