// /src/shims-vue.d.ts
/**
* shims-vue.d.ts的作⽤
* 为了typeScript做的适配定义⽂件，因为.vue⽂件不是⼀个常规的⽂件类型，ts是不能理解.vue⽂件是⼲嘛的，
* 加这⼀段是是告诉ts，vue⽂件是这种类型的。
* 可以把这⼀段删除，会发现import的所有vue类型的⽂件都会报错。
 */
declare module '*.vue' {
  // Vue 3
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}