<template>
  <div class="main van-safe-area-top">
    <div v-if="loading" class="global_loading"></div>
    <router-view v-slot="{ Component }">
      <keep-alive :include="pageCaches">
        <component :is="Component" />
      </keep-alive>
    </router-view>
  </div>
</template>

<script lang="ts">
import { mapGetters } from "vuex";
export default {
  name: "App",
  computed: {
    ...mapGetters(["loading", "pageCaches"]),
  },
};
</script>
<style lang="scss" scoped>
.main {
  width: 100%;
  box-sizing: border-box;
  position: relative;
  min-height: 100vh;
}
</style>
