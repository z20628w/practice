import request from '@/utils/request';

/**
 * 商品排行
*/

// 根据加盟商获取商品排行榜
export function statisticssdOrderorderCommodityRankList (params, load = true) {
  return request({
    url: '/statistics/sdOrder/orderCommodityRankList',
    method: 'post',
    params
  }, load);
}


