import request from '@/utils/request';

// 获取加盟商列表
export function statisticssdOrderbaList (params, load = true) {
  return request({
    url: '/statistics/sdOrder/baList',
    method: 'post',
    params
  }, load);
}

// 获取加盟商所属门店/设备列表
export function statisticssdOrderbasdList (params, load = true) {
  return request({
    url: '/statistics/sdOrder/basdList',
    method: 'post',
    params
  }, load);
}

// 获取实收汇总数据，按指定日期
export function statisticssdOrderbasdRealIncome (params, load = true) {
  return request({
    url: '/statistics/sdOrder/basdRealIncome',
    method: 'post',
    params
  }, load);
}

// 获取实收图表数据，按指定日期
export function statisticssdOrderbasdRealIncomeList (params, load = true) {
  return request({
    url: '/statistics/sdOrder/basdRealIncomeList',
    method: 'post',
    params
  }, load);
}

// 获取支付和退款汇总数据，按指定日期
export function statisticssdOrderbasdPaidReturnInfo (params, load = true) {
  return request({
    url: '/statistics/sdOrder/basdPaidReturnInfo',
    method: 'post',
    params
  }, load);
}

// 获取支付和退款图表数据，按指定日期
export function statisticssdOrderbasdPaidReturnInfoList (params, load = true) {
  return request({
    url: '/statistics/sdOrder/basdPaidReturnInfoList',
    method: 'post',
    params
  }, load);
}

// 获取注册，活跃，统计用户数
export function statisticsuseruserRAVInfo (params, load = true) {
  return request({
    url: '/statistics/user/userRAVInfo',
    method: 'post',
    params
  }, load);
}

// 获取注册，活跃，统计用户数
export function statisticsuseruserRAVInfoList (params, load = true) {
  return request({
    url: '/statistics/user/userRAVInfoList',
    method: 'post',
    params
  }, load);
}

// 用户成交数据统计数据
export function statisticsuseruserDealInfo (params, load = true) {
  return request({
    url: '/statistics/user/userDealInfo',
    method: 'post',
    params
  }, load);
}

// 用户成交数据图表数据
export function statisticsuseruserDealInfoList (params, load = true) {
  return request({
    url: '/statistics/user/userDealInfoList',
    method: 'post',
    params
  }, load);
}

// 用户成交，注册，活跃等数据的统计
export function statisticsuseruserDealRAVInfo (params, load = true) {
  return request({
    url: '/statistics/user/userDealRAVInfo',
    method: 'post',
    params
  }, load);
}

// 用户成交，注册，活跃等数据的图表数据
export function statisticsuseruserDealRAVInfoList (params, load = true) {
  return request({
    url: '/statistics/user/userDealRAVInfoList',
    method: 'post',
    params
  }, load);
}
