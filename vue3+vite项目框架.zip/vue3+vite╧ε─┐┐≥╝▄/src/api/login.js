import request from '@/utils/request';

// 登录方法（密码登录）
export function login_pass (params, load = true) {
	return request({
		url: '/statistics/apiSecurity/loginWithPassword',
		method: 'post',
		params
	}, load);
}

// 登录方法（验证码登录）
export function login_code (params, load = true) {
	return request({
		url: '/statistics/apiSecurity/loginWithCaptcha',
		method: 'post',
		params
	}, load);
}

// 获取登录验证码
export function get_loginCode (params, load = true) {
	return request({
		url: '/statistics/apiSecurity/sendCaptcha',
		method: 'post',
		params
	}, load);
}


