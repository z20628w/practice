import request from '@/utils/request';

/**
 * 营业点排行
*/

// 根据加盟商获取门店/设备排行榜
export function statisticssdOrdersdRealIncomeRankList (params, load = true) {
  return request({
    url: '/statistics/sdOrder/sdRealIncomeRankList',
    method: 'post',
    params
  }, load);
}
