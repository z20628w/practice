import request from '@/utils/request';

/**
 * 充值相关数据获取
*/

// 充值汇总数据
export function statisticsrecharge (params, load = true) {
  return request({
    url: '/statistics/recharge/recharge',
    method: 'post',
    params
  }, load);
}

// 充值图表数据
export function statisticsrechargeList (params, load = true) {
  return request({
    url: '/statistics/recharge/rechargeList',
    method: 'post',
    params
  }, load);
}

// 余额汇总数据
export function statisticsrechargebalanceRemain (params, load = true) {
  return request({
    url: '/statistics/recharge/balanceRemain',
    method: 'post',
    params
  }, load);
}

// 余额图表数据
export function statisticsrechargeListbalanceRemainList (params, load = true) {
  return request({
    url: '/statistics/recharge/balanceRemainList',
    method: 'post',
    params
  }, load);
}

// 余额消费汇总数据
export function statisticsrechargebalanceConsume (params, load = true) {
  return request({
    url: '/statistics/recharge/balanceConsume',
    method: 'post',
    params
  }, load);
}

// 余额消费图表数据
export function statisticsrechargeListbalanceConsumeList (params, load = true) {
  return request({
    url: '/statistics/recharge/balanceConsumeList',
    method: 'post',
    params
  }, load);
}
