import request from '@/utils/request';

/**
 * 资金消耗排行
*/

// 余额消费排行
export function statisticsrechargebalanceConsumeRankList (params, load = true) {
  return request({
    url: '/statistics/recharge/balanceConsumeRankList',
    method: 'post',
    params
  }, load);
}
