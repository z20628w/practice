import request from '@/utils/request';

/**
 * 加盟商排行
*/

// 根据加盟商获取加盟商排行榜
export function statisticssdOrderbaRealIncomeRankList (params, load = true) {
  return request({
    url: '/statistics/sdOrder/baRealIncomeRankList',
    method: 'post',
    params
  }, load);
}


