const path = require('path')
// vite.config.js # or vite.config.ts
import vue from '@vitejs/plugin-vue'

import { defineConfig, loadEnv } from 'vite'

// 自动按需导入插件
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver, VantResolver } from 'unplugin-vue-components/resolvers'

//gzip静态资源压缩
import viteCompression from 'vite-plugin-compression'

function resolve (dir) {
  return path.join(__dirname, dir)
}

module.exports = ({ mode }) => {
  return defineConfig({
    /**
     * 在生产中服务时的基本公共路径。
     * @default '/'
    */
    base: './',

    resolve: {
      alias: {
        '@': resolve('src')
      },
    },

    css: {
      preprocessorOptions: {
        // 给 sass-loader 传递选项
        // sass: {
        // @/ 是 src/ 的别名
        // 所以这里假设你有 `src/variables.sass` 这个文件
        // 注意：在 sass-loader v8 中，这个选项名是 "prependData"
        //   additionalData: `@import "@/assets/css/common.scss"`
        // },
        // 默认情况下 `sass` 选项会同时对 `sass` 和 `scss` 语法同时生效
        // 因为 `scss` 语法在内部也是由 sass-loader 处理的
        // 但是在配置 `prependData` 选项的时候
        // `scss` 语法会要求语句结尾必须有分号，`sass` 则要求必须没有分号
        // 在这种情况下，我们可以使用 `scss` 选项，对 `scss` 语法进行单独配置
        scss: {
          additionalData: `@import "@/assets/css/common.scss";`
        },
        // 给 less-loader 传递 Less.js 相关选项
        // less: {
        // http://lesscss.org/usage/#less-options-strict-units `Global Variables`
        // `primary` is global variables fields name
        //   globalVars: {
        //     primary: '#fff'
        //   }
        // }
      }
    },

    plugins: [
      vue(),
      AutoImport({
        resolvers: [ElementPlusResolver()],
      }),
      Components({
        resolvers: [ElementPlusResolver(), VantResolver()],
      }),
      viteCompression({
        verbose: true,
        disable: false,
        threshold: 10240,
        algorithm: 'gzip',
        ext: '.gz',
      })
    ],

    build: {
      /**
       * 与“根”相关的目录，构建输出将放在其中。如果目录存在，它将在构建之前被删除。
       * @default 'dist'
       */
      outDir: '../data_statistics_APP_H5/index',

      // 指定生成静态资源的存放路径
      assetsDir: "assets",

      assetsPublicPath: "/",

      // 小于此阈值的导入或引用资源将内联为 base64 编码，以避免额外的 http 请求。设置为 0 可以完全禁用此项。
      assetsInlineLimit: 4096,

      // 启用/禁用 CSS 代码拆分。当启用时，在异步 chunk 中导入的 CSS 将内联到异步 chunk 本身，并在其被加载时插入。
      cssCodeSplit: true,

      // 构建时清空该目录
      emptyOutDir: true,

      // 服务端渲染
      ssr: false,

      target: 'es2020',

      rollupOptions: {
        output: {
          // 将文件分开
          // chunkFileNames: 'static/js/[name]-[hash].js',
          // entryFileNames: 'static/js/[name]-[hash].js',
          // assetFileNames: 'static/[ext]/[name]-[hash].[ext]',

          // 超大静态资源拆分
          manualChunks (id) {
            if (id.includes('node_modules')) {
              return id.toString().split('node_modules/')[1].split('/')[0].toString();
            }
          }
        }
      },

      // 清除console和debugger
      terserOptions: {
        compress: {
          drop_console: true,
          drop_debugger: true,
        },
      },
    },

    optimizedeps: {
      esbuildoptions: {
        target: 'es2020'
      }
    },

    server: {
      host: true,//本地主机ip

      port: 3000,//端口

      open: true,// 是否自动在浏览器打开

      https: true,// 是否开启 https

      proxy: {
        [`${loadEnv(mode, process.cwd()).VITE_APP_BASE_API}`]: {
          target: loadEnv(mode, process.cwd()).VITE_APP_BASE_URL, // 线上
          rewrite: (path) => {
            let reg = new RegExp(`^\\${loadEnv(mode, process.cwd()).VITE_APP_BASE_API}`);
            return path.replace(reg, '')
          },
          changeOrigin: true,
          ws: true
        }
      }
    }
  })
}